# Ingesting data from the local filesystem

```python
```
