# Python scripting

:TODO: Overview of writing scripts, getting config, etc.
