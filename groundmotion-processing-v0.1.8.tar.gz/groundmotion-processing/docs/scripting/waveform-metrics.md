# Computing waveform metrics

```python
```
