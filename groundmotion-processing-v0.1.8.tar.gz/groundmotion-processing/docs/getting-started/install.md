# Installation

See [README](https://github.com/usgs/groundmotion-processing) at the top-level source directory.

## Dependencies

:TODO: List Dependencies

## Installing via conda

:TODO: Explain how to install via conda.

## Installing from source

:TODO: Explain how to use the `install.sh` script.
