# Computing station metrics

:TODO: Write this section.

:TODO: Add table with station metrics.
