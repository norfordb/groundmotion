# Windowing Data

:TODO: Write this section.
