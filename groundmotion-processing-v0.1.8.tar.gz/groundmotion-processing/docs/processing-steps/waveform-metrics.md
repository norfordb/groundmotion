# Computing waveform metrics

:TODO: Write this section.

:TODO: Add table of intensity metrics.

:TODO: Add table of components.
