# Removing Instrument Response

:TODO: Write this section.
