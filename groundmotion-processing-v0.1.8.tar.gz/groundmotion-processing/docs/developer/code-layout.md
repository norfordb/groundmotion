# Code layout

:TODO: Overview of code layout.
