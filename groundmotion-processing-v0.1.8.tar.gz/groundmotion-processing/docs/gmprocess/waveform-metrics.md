# Computing waveform metrics

:TODO: Write this section.
