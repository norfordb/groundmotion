"""
Base class for exceptions in pgm.
"""


class PGMException(Exception):
    """Base class for exceptions in pgm."""
    pass
