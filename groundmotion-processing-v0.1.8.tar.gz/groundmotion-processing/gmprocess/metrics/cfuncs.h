void calculate_spectrals_c(double *times, double *acc, int np, double period,
	                       double damping, double *sacc, double *svel,
						   double *sdis);
